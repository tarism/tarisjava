

// His name is "anselm".


// alert("Hello Welcome to our site.");
// window.alert( ' His name is "taris". ' );


// console.log('Hello to Console!');
// console.error('Hello to Console!');
// console.warn('Hello to Console!');



// var welcomeToUser = "Welcome to my site taris";

// var userName;
// userName = 'taris';
// // alert(welcomeToUser);
// // console.log('welcomeToUser');
// console.log(userName);
// userName = 'Haider';
// console.log(userName);

// var userAlert ="";
// var rose;
// var Rose;












// alert(500 + 700);
// console.log(500 + 700);

// var firstSubject =500;
// var secondSubject=700;
// console.log(firstSubject + secondSubject);





// var userInput = prompt('What is your name?');

// console.log('Welcome to ' + userInput);




// console.log((6 + 2) * 7 / 2);

// var num = 23;
// console.log(num % 5);



// var userInput = prompt('what is your name?', 'Haider');
// var userDonation = prompt('How much you want to donate?', '1000$');
// var message = 'Welcome ';
// var punc = "!"
// console.log(message + userInput + punc);


// var firstSubject ="10";
// var secondSubject="3";
// console.log( 2 - firstSubject + secondSubject);






// var num = 7;
             
//             // 7     +   9   + 9    +    7
// console.log(num++ + ++num + num-- + --num);


var num = 3;
            //  3    - 5 +   1   + 2 - 1     + 3
console.log(num-- - 5 + --num + 2 - num++ + ++num);








