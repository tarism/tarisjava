



// var today = new Date();
// console.log(today.getDay());
// var todayDay = today.getDay();
// var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
// console.log(days[todayDay])






// var today = new Date();
// var currentMonth = today.getMonth();
// console.log(currentMonth);




// var today = new Date();
// console.log(today);
// today.setFullYear(2017);
// console.log(today);






// var today = new Date();
// console.log(today);

// var taris = new Date('August 14, 2020 09:00:00');
// console.log(taris);








// var myBirthday = new Date('Febuary 07, 2020');
// // console.log(myBirthday);
// var today = new Date();
// // console.log(today);

// var birthdayMilliseconds = myBirthday.getTime();
// // console.log(birthdayMilliseconds);
// var todayMilliseconds = today.getTime();
// // console.log(todayMilliseconds);

// var remainingDays = birthdayMilliseconds- todayMilliseconds;
// console.log(Math.floor(remainingDays / (1000*60*60*24)));

















// if (dayOfWk === "Sat" || dayOfWk === "Sun") {
//     alert("Whoopee!");
// }
// else if (dayOfWk === "Fri") {
//     alert("TGIF!");
// }
// else {
//     alert("Shoot me now!");
// }






// var dayOfWk = 'Sat';
// switch (dayOfWk) {
//     case "Sat":
//         alert("Whoopee");
//         break;
//     case "Sun":
//         alert("Whoopee");
//         break;
//     case "Fri":
//         alert("TGIF!");
//         break;
//     default: 
//          alert("Shoot me now!");
// }






var arr = ['apple', 'banana', 'cherry', 'grapes', 'mango', 'orange', 'straberry'];

// for (var i = 0; i < arr.length; i++) {
//     console.log(arr[i], 'for loop');
// }

// var i = 0;
// while (i < arr.length) {
//     console.log(arr[i], 'while loop');
//     // var userIncrement = +prompt('provide anumber')
//     i++;
// }


var i = 0;
do {
    console.log(arr[i], 'do while loop');
    // var userIncrement = +prompt('provide anumber')
    i++;
} while (i < 0)







