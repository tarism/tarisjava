// var city1 = 'Karachi';
// var city2 = 'Lahore';
// var city3 = 'Islamabad';
// var city4 = 'Rawalpindi';
// var city5 = 'Multan';
// var city6 = 'Hyderabad';

// var cities = ["Karachi", "Lahore", "Islamabad", "Rawalpindi", "Multan", "Hyderabad"];
// console.log(cities[2]);














// var arr = [];
// console.log(arr);

// arr[0] = 'haider';
// arr[2] = 'Ali';

// console.log(arr);



// // Pop Method remove last index of an arrey;

// var numArr = [1,2,3,4,5,6];
// console.log(numArr);
// numArr.pop();
// console.log(numArr);





// Push Method insert at last index of an arrey;


// var userName = prompt('what is your name?');
// var userNamesArr = ['angelina', 'ayshal', 'arya'];
// userNamesArr.push(userName);
// console.log(userNamesArr);


// shift Method remove first index of an arrey;

// var arr = [0,1,2,3,4,5,6];
// arr.shift();
// console.log(arr);


// unshift Method adds at first index of an arrey;
// var arr = [0, 1, 2, 3, 4, 5, 6];
// arr.unshift(-1);
// console.log(arr);





//splice method adds or removes at your 
// desired index. 

// var yourFavFruit = prompt('let us know your favorite fruit');
// var myFavFruits = ['apple', 'banana','orange', 'mango'];
// myFavFruits.splice(1,0, yourFavFruit,'guava');
// console.log(myFavFruits);


//slice method creates a refrence of required indexes
// var arr = [-1, 5, 1, 2, 3, 4, 5];
// var arr2 = arr.slice(2, 5);
// console.log(arr2);





// var cities = ["Karachi", "Lahore", "Islamabad", "Rawalpindi", "Multan", "Hyderabad"];
// console.log(cities.length);














// *************Tasks 1************


// var userInput = +prompt('type a number');
// if(userInput % 3 === 0){
//     console.log('divide done');
// }
// else{
//     console.log('divide not possible');
// }




// ********** Task 2 Calculator******

// var num1 = +prompt('type first number'); 
// var operator = prompt('type required operator');
// var num2 = +prompt('type second number');
// var result;
// if(operator === '+'){
//     result = num1 + num2;
// }
// else if(operator === '-'){
//     result = num1 - num2;
// }
// else if(operator === '*'){
//     result = num1 * num2;
// }
// else if(operator === '/'){
//     result = num1 / num2;
// }
// else if(operator === '%'){
//     result = num1 % num2;
// }
// console.log(result);














// //*******Task 3******* */

// var answers = [1,2]

// var userInput = prompt('type pass code');
// var userInput2 = prompt('type pass code');
// if((userInput == answers[0] || userInput == answers[1]) && (userInput2 == answers[0] || userInput2 == answers[1])){
//     console.log('authorized');
// }
// else{
//     console.log('unauthorized');
// }







// *********Task 4**********


var arr = [0, 1, 2, 3, 4, 5, 6];



